package com.example.mystoryapp.data

import com.example.mystoryapp.response.*
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import retrofit2.Call

object Dummy {

    fun DummyListStory(): Story{
        val data = ArrayList<ListStoryItem>()
        for (i in 0 .. 200){
            val list = ListStoryItem(
                "link",
                "2002-10-11",
                "hildan",
                "SIB",
                "$i",
                -6.72818,
                10.0020
            )
            data.add(list)
        }
        return Story(data, false, "success")
    }
    fun dummyStory(): List<ListStoryItem>{
        val data :MutableList<ListStoryItem> = arrayListOf()

        for (i in 0 .. 200){
            val list = ListStoryItem(
                "link",
                "2002-10-11",
                "hildan",
                "SIB",
                "$i",
                -6.72818,
                10.0020
            )
            data.add(list)
        }
        return data
    }

    fun loginResponse():Login {
        return Login(
            LoginResult("Hildan","hildan23","hildan1234567"),
            false,
            "login success"
        )
    }
    fun loginResponseCall():Call <Login> {
        Login(
            LoginResult("Hildan","hildan23","hildan1234567"),
            false,
            "login success"
        )
        return loginResponseCall ()
    }

    fun registerResponse(): Register{
        return Register(
            false, "Register success"
        )
    }
    fun dummyDesc() : RequestBody {
        val text ="hildan"
        return text.toRequestBody()
    }
    fun dummyImage() : MultipartBody.Part {
        val text ="hildan"
        return MultipartBody.Part.create(text.toRequestBody())
    }

    fun storyResponse(): Story {
        return Story(
            listOf(),
            false,
            "getStory Success"
        )
    }

    fun uploadResponse(): UploadStory{
        return UploadStory(
            false,
            "Upload Story Success"
        )
    }
}