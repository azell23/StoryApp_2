package com.example.mystoryapp.viewmodel

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import com.example.mystoryapp.data.Dummy
import com.example.mystoryapp.repository.MapsRepo
import com.example.mystoryapp.response.ListStoryItem
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.junit.MockitoJUnitRunner

@RunWith(MockitoJUnitRunner::class)
class StoryMapsTest{

    @get:Rule
    val instantTaskExecutorRule = InstantTaskExecutorRule()

    @Mock
    private lateinit var viewModel : StoryMaps

    @Test
    fun getStoryReturnSuccess()= runTest {
        val observer = Observer<List<ListStoryItem>>{}
        val dummy = Dummy.dummyStory()

        try {
            val expectedData = MutableLiveData<List<ListStoryItem>>()
            expectedData.value = dummy

            Mockito.`when`(viewModel.getStoryWithMaps("token")).thenReturn(expectedData)

            val actualData = viewModel.getStoryWithMaps("token").observeForever(observer)
            Mockito.verify(viewModel).getStoryWithMaps("token")
            assertNotNull(actualData)
        } finally {
            viewModel.getStoryWithMaps("token").removeObserver(observer)
        }
    }
}