package com.example.mystoryapp.viewmodel

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import com.example.mystoryapp.data.MainDispatcherRule
import com.example.mystoryapp.data.getOrAwait
import com.example.mystoryapp.datastore.AuthPreference
import com.example.mystoryapp.repository.AuthRepo
import com.google.android.gms.common.internal.Asserts
import kotlinx.coroutines.*
import kotlinx.coroutines.test.*
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.junit.MockitoJUnitRunner

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(MockitoJUnitRunner::class)
class AuthTest{

    @get:Rule
    val instantExecutorRule = InstantTaskExecutorRule()

    @get:Rule
    val mainDispatcherRule = MainDispatcherRule()

    @Mock
    private lateinit var repository: AuthRepo
    private lateinit var preference: AuthPreference
    private lateinit var viewModel: Auth


    @Before
    fun setup(){
        repository = AuthRepo()
        preference = AuthPreference(Mockito.mock(android.content.Context::class.java))
        viewModel = Auth(repository)
    }

    @After
    fun tearDown(){
    }

    @Test
    fun loginSuccess() = runTest {
        viewModel.login("rizky@gmail.com","ramadhan")
        assertFalse(false)
        assertNotNull("not null")
    }
    @Test
    fun registerSuccess() = runTest {
        viewModel.register("hildan","hildan@gmail.com","hildan23")
        assertFalse(false)
        assertNotNull("not null")
    }
}