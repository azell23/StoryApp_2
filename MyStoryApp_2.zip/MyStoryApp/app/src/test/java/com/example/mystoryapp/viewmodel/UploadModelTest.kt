package com.example.mystoryapp.viewmodel

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import com.example.mystoryapp.data.Dummy
import com.example.mystoryapp.repository.UploadRepo
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.junit.MockitoJUnitRunner


@RunWith(MockitoJUnitRunner::class)
class UploadModelTest{

    @get:Rule
    val instantExecutorRule = InstantTaskExecutorRule()

    @Mock
    private lateinit var viewModel : UploadModel

    @Test

    fun addStoryReturnFailed() = runTest {
        val image = Dummy.dummyImage()
        val desc = Dummy.dummyDesc()
        viewModel.upload("token",image, desc)
        assertTrue(true)
        assertNotNull("not null")
    }
    @Test
    fun addStoryWithLocationsReturnFailed()= runTest {
        val image = Dummy.dummyImage()
        val desc = Dummy.dummyDesc()
        viewModel.uploadWithLocations("token",image, desc,10.20,23.32)
        assertTrue(true)
        assertNotNull("not null")
    }
}