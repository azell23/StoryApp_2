package com.example.mystoryapp.data

import android.content.Context
import com.example.mystoryapp.datastore.AuthPreference

class FakePreference {

    private var token: String? = null
    private var status = false





}